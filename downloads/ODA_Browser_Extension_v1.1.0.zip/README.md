# ODA Browser Integration Extension (Chrome / Edge / Brave / Opera)

This extension connects Google Chrome, Microsoft Edge, Brave, and other Chromium browsers directly with ODA (Omni Download Assistant).

## How It Solves the "HTML / 404 Download" Problem on Streaming Websites:
Websites like WCO, anime portals, and movie streaming sites hide their video files behind client-side JavaScript, session tokens, and dynamic players. When you copy the browser address bar link (`.html`), you only copy the webpage code, not the video.

The **ODA Browser Extension** intercepts the real, underlying `.mp4` or `.m3u8` media streams while the video is playing in your browser. With a single click on **"Download with ODA"**, it transmits the authenticated stream URL, cookies, and referer directly into ODA for full multi-threaded high-speed downloading.

---

## 🚀 How to Install in 10 Seconds:

### In Google Chrome / Brave:
1. Open Chrome and navigate to: `chrome://extensions/`
2. Turn ON the **"Developer mode"** toggle in the top-right corner.
3. Click the **"Load unpacked"** button in the top-left corner.
4. Select this `extension` folder:
   `C:\Users\User\.gemini\antigravity\scratch\oda-download-assistant\extension`
5. That's it! Pin the ODA icon to your browser toolbar.

### In Microsoft Edge:
1. Open Edge and navigate to: `edge://extensions/`
2. Turn ON **"Developer mode"** in the left sidebar.
3. Click **"Load unpacked"** and select this `extension` folder.

---

## 🎬 How to Use:
1. Make sure ODA is open on your desktop.
2. Go to any video website (e.g. `wco.tv`, YouTube, movie or anime sites).
3. Start playing the video.
4. Click the **ODA icon** in your browser toolbar or the floating download button.
5. Click **"⚡ Download with ODA"**!
6. ODA will instantly capture the high-speed stream and download the actual video file!
