// ODA Browser Integration - Background Service Worker (Manifest V3)

const ODA_SERVER_URL = "http://127.0.0.1:48912";
const mediaByTab = {};

// Clean up tab media cache
chrome.tabs.onRemoved.addListener((tabId) => {
  delete mediaByTab[tabId];
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    mediaByTab[tabId] = [];
    chrome.action.setBadgeText({ text: "", tabId: tabId });
  }
});

// Helper to check if URL is media
function isMediaUrl(url) {
  if (!url || typeof url !== "string") return false;
  const clean = url.split("?")[0].toLowerCase();
  return (
    clean.endsWith(".mp4") ||
    clean.endsWith(".m3u8") ||
    clean.endsWith(".webm") ||
    clean.endsWith(".mkv") ||
    clean.endsWith(".ts") ||
    clean.endsWith(".m4s") ||
    clean.endsWith(".mp3") ||
    clean.endsWith(".wav") ||
    clean.endsWith(".m4a") ||
    clean.endsWith(".flac") ||
    clean.endsWith(".aac")
  );
}

function getMediaFormat(url, contentType) {
  const clean = url.split("?")[0].toLowerCase();
  if (clean.endsWith(".m3u8") || (contentType && contentType.includes("mpegurl"))) return "M3U8 (HLS Video)";
  if (clean.endsWith(".mp4") || (contentType && contentType.includes("mp4"))) return "MP4 Video";
  if (clean.endsWith(".webm") || (contentType && contentType.includes("webm"))) return "WebM Video";
  if (clean.endsWith(".mkv")) return "MKV Video";
  if (clean.endsWith(".mp3") || (contentType && contentType.includes("audio/mpeg"))) return "MP3 Audio";
  if (clean.endsWith(".m4a")) return "M4A Audio";
  if (clean.endsWith(".ts")) return "TS Stream Segment";
  return "Media Stream";
}

function recordMedia(tabId, url, contentType, size) {
  if (!tabId || tabId < 0) return;
  if (!mediaByTab[tabId]) mediaByTab[tabId] = [];

  // Ignore TS fragments if we already have the m3u8 playlist
  if (url.includes(".ts") && mediaByTab[tabId].some(m => m.url.includes(".m3u8"))) {
    return;
  }

  // Avoid duplicates
  const existing = mediaByTab[tabId].find(m => m.url === url);
  if (existing) {
    if (size && !existing.size) existing.size = size;
    return;
  }

  chrome.tabs.get(tabId, (tab) => {
    const pageTitle = (tab && tab.title) ? tab.title : "Video Stream";
    const pageUrl = (tab && tab.url) ? tab.url : "";

    const item = {
      url: url,
      title: pageTitle,
      referer: pageUrl,
      format: getMediaFormat(url, contentType),
      size: size || 0,
      timestamp: Date.now()
    };

    // Prioritize master .m3u8 or .mp4 over .ts segments
    if (url.includes(".m3u8") || url.includes(".mp4")) {
      mediaByTab[tabId].unshift(item);
    } else {
      mediaByTab[tabId].push(item);
    }

    const count = mediaByTab[tabId].length;
    chrome.action.setBadgeText({ text: String(count), tabId: tabId });
    chrome.action.setBadgeBackgroundColor({ color: "#1f6feb", tabId: tabId });
  });
}

// Track request headers by URL
const requestHeadersByUrl = {};

chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    if (details.url && details.requestHeaders) {
      const hMap = {};
      for (const h of details.requestHeaders) {
        hMap[h.name.toLowerCase()] = h.value;
      }
      requestHeadersByUrl[details.url] = hMap;
      if (details.tabId > 0 && mediaByTab[details.tabId]) {
        const item = mediaByTab[details.tabId].find(m => m.url === details.url);
        if (item) {
          item.requestHeaders = hMap;
        }
      }
    }
  },
  { urls: ["<all_urls>"] },
  ["requestHeaders"]
);

// 1. Inspect onBeforeRequest for direct media extension URLs
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    if (details.tabId > 0 && isMediaUrl(details.url)) {
      recordMedia(details.tabId, details.url, null, 0);
    }
  },
  { urls: ["<all_urls>"] }
);

// 2. Inspect onResponseStarted for Content-Type headers
chrome.webRequest.onResponseStarted.addListener(
  (details) => {
    if (details.tabId <= 0) return;
    const headers = details.responseHeaders || [];
    let contentType = "";
    let contentLength = 0;

    for (const h of headers) {
      const name = h.name.toLowerCase();
      if (name === "content-type") contentType = h.value.toLowerCase();
      if (name === "content-length") contentLength = parseInt(h.value, 10) || 0;
    }

    const isMedia = (
      contentType.startsWith("video/") ||
      contentType.startsWith("audio/") ||
      contentType.includes("application/x-mpegurl") ||
      contentType.includes("application/vnd.apple.mpegurl") ||
      isMediaUrl(details.url)
    );

    if (isMedia) {
      recordMedia(details.tabId, details.url, contentType, contentLength);
    }
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

// Handle messaging between popup / content script / ODA
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "GET_MEDIA") {
    const tabId = request.tabId;
    const items = mediaByTab[tabId] || [];
    sendResponse({ media: items });
    return true;
  }

  if (request.type === "RECORD_FROM_DOM") {
    const tabId = sender.tab ? sender.tab.id : request.tabId;
    if (tabId && request.url) {
      recordMedia(tabId, request.url, request.contentType, 0);
    }
    sendResponse({ status: "ok" });
    return true;
  }

  if (request.type === "PING_ODA") {
    fetch(`${ODA_SERVER_URL}/ping`, { method: "GET" })
      .then((res) => res.json())
      .then((data) => sendResponse({ connected: true, data: data }))
      .catch((err) => sendResponse({ connected: false, error: err.message }));
    return true;
  }

  if (request.type === "SEND_TO_ODA") {
    const captured = requestHeadersByUrl[request.url] || {};
    let ref = captured["referer"] || request.referer || "";
    if (!ref && request.url && (request.url.includes("wcostream") || request.url.includes("wcofun"))) {
      ref = "https://embed.wcostream.com/";
    }

    const headers = {
      "Referer": ref,
      "User-Agent": captured["user-agent"] || navigator.userAgent
    };
    if (captured["origin"]) {
      headers["Origin"] = captured["origin"];
    }

    const payload = {
      url: request.url,
      title: request.title,
      referer: ref,
      headers: headers
    };

    fetch(`${ODA_SERVER_URL}/add_download`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    })
      .then((res) => res.json())
      .then((data) => sendResponse({ success: true, data: data }))
      .catch((err) => sendResponse({ success: false, error: err.message }));
    return true;
  }
});
