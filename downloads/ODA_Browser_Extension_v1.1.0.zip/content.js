// ODA Content Script - DOM Video Sniffer and Floating Button

function scanDOMMedia() {
  const videos = document.querySelectorAll("video");
  videos.forEach((v) => {
    const src = v.currentSrc || v.src;
    if (src && src.startsWith("http")) {
      chrome.runtime.sendMessage({
        type: "RECORD_FROM_DOM",
        url: src,
        contentType: "video/mp4"
      });
    }

    // Attach play event listener
    if (!v.dataset.odaAttached) {
      v.dataset.odaAttached = "true";
      v.addEventListener("play", () => {
        const playSrc = v.currentSrc || v.src;
        if (playSrc && playSrc.startsWith("http")) {
          chrome.runtime.sendMessage({
            type: "RECORD_FROM_DOM",
            url: playSrc,
            contentType: "video/mp4"
          });
        }
      });
    }
  });
}

// Initial scan and periodic check for dynamically inserted players (SPA / iframe wrappers)
scanDOMMedia();
setInterval(scanDOMMedia, 3000);

// Observer for newly inserted video nodes
const observer = new MutationObserver(() => {
  scanDOMMedia();
});
observer.observe(document.body || document.documentElement, {
  childList: true,
  subtree: true
});
