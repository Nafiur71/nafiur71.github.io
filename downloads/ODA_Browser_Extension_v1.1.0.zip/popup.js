// ODA Popup Script

function formatBytes(bytes) {
  if (!bytes || bytes <= 0) return "";
  const units = ["B", "KB", "MB", "GB"];
  let i = 0;
  let val = bytes;
  while (val >= 1024 && i < units.length - 1) {
    val /= 1024;
    i++;
  }
  return ` (${val.toFixed(1)} ${units[i]})`;
}

document.addEventListener("DOMContentLoaded", () => {
  const statusBadge = document.getElementById("statusBadge");
  const statusText = document.getElementById("statusText");
  const pageInfo = document.getElementById("pageInfo");
  const mediaList = document.getElementById("mediaList");
  const emptyState = document.getElementById("emptyState");
  const btnRefresh = document.getElementById("btnRefresh");

  let currentTabId = null;

  async function pingServer(url) {
    try {
      const ctrl = new AbortController();
      const tid = setTimeout(() => ctrl.abort(), 1200);
      const res = await fetch(`${url}/ping`, { method: "GET", signal: ctrl.signal });
      clearTimeout(tid);
      const data = await res.json();
      return (data && data.status === "ok");
    } catch (e) {
      return false;
    }
  }

  async function checkAppStatus() {
    // 1. Try direct fetch to 127.0.0.1
    if (await pingServer("http://127.0.0.1:48912")) {
      statusBadge.className = "status-badge online";
      statusText.textContent = "ODA Connected";
      return;
    }
    // 2. Try direct fetch to localhost
    if (await pingServer("http://localhost:48912")) {
      statusBadge.className = "status-badge online";
      statusText.textContent = "ODA Connected";
      return;
    }
    // 3. Try background service worker
    chrome.runtime.sendMessage({ type: "PING_ODA" }, (res) => {
      if (res && res.connected) {
        statusBadge.className = "status-badge online";
        statusText.textContent = "ODA Connected";
      } else {
        statusBadge.className = "status-badge";
        statusText.textContent = "ODA App Offline";
      }
    });
  }

  function loadMedia() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0]) return;
      const tab = tabs[0];
      currentTabId = tab.id;
      pageInfo.textContent = tab.title || tab.url;

      chrome.runtime.sendMessage({ type: "GET_MEDIA", tabId: tab.id }, (res) => {
        const items = (res && res.media) ? res.media : [];
        renderMedia(items, tab);
      });
    });
  }

  function renderMedia(items, tab) {
    mediaList.innerHTML = "";

    if (!items || items.length === 0) {
      emptyState.style.display = "block";
      return;
    }

    emptyState.style.display = "none";

    items.forEach((item, index) => {
      const card = document.createElement("div");
      card.className = "media-card";

      const title = document.createElement("div");
      title.className = "media-title";
      title.textContent = item.title || `Video Stream #${index + 1}`;

      const meta = document.createElement("div");
      meta.className = "meta-row";

      const formatTag = document.createElement("span");
      const isM3u8 = item.url.includes(".m3u8");
      formatTag.className = isM3u8 ? "format-tag m3u8" : "format-tag";
      formatTag.textContent = item.format || (isM3u8 ? "M3U8 HLS" : "MP4 Video");

      const sizeTag = document.createElement("span");
      sizeTag.className = "size-tag";
      sizeTag.textContent = formatBytes(item.size);

      meta.appendChild(formatTag);
      if (item.size > 0) meta.appendChild(sizeTag);

      const actions = document.createElement("div");
      actions.className = "actions";

      const btnDownload = document.createElement("button");
      btnDownload.className = "btn-download";
      btnDownload.innerHTML = "⚡ Download with ODA";
      btnDownload.addEventListener("click", async () => {
        btnDownload.disabled = true;
        btnDownload.innerHTML = "Sending...";

        let ref = item.referer || tab.url || "";
        if (!ref && item.url && (item.url.includes("wcostream") || item.url.includes("wcofun"))) {
          ref = "https://embed.wcostream.com/";
        }

        const payload = {
          url: item.url,
          title: item.title,
          referer: ref,
          headers: {
            "Referer": ref,
            "User-Agent": navigator.userAgent
          }
        };

        let sent = false;
        // Try direct fetch to 127.0.0.1
        try {
          const res = await fetch("http://127.0.0.1:48912/add_download", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
          });
          const data = await res.json();
          if (data && (data.status === "queued" || data.status === "ok")) {
            sent = true;
          }
        } catch (e1) {
          // Try direct fetch to localhost
          try {
            const res2 = await fetch("http://localhost:48912/add_download", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(payload)
            });
            const data2 = await res2.json();
            if (data2 && (data2.status === "queued" || data2.status === "ok")) {
              sent = true;
            }
          } catch (e2) {}
        }

        if (!sent) {
          // Try background worker
          sent = await new Promise((resolve) => {
            chrome.runtime.sendMessage({
              type: "SEND_TO_ODA",
              url: item.url,
              title: item.title,
              referer: item.referer || tab.url
            }, (res) => {
              resolve(Boolean(res && res.success));
            });
          });
        }

        if (sent) {
          btnDownload.innerHTML = "✅ Sent to ODA!";
          btnDownload.style.background = "#238636";
          statusBadge.className = "status-badge online";
          statusText.textContent = "ODA Connected";
        } else {
          // If ODA is offline or not running, copy stream URL to clipboard automatically!
          navigator.clipboard.writeText(item.url);
          btnDownload.innerHTML = "📋 Copied! Open ODA & Paste";
          btnDownload.style.background = "#d29922";
          setTimeout(() => {
            btnDownload.disabled = false;
            btnDownload.innerHTML = "⚡ Download with ODA";
            btnDownload.style.background = "#1f6feb";
          }, 4000);
        }
      });

      const btnCopy = document.createElement("button");
      btnCopy.className = "btn-copy";
      btnCopy.textContent = "Copy Link";
      btnCopy.addEventListener("click", () => {
        navigator.clipboard.writeText(item.url).then(() => {
          btnCopy.textContent = "Copied!";
          setTimeout(() => { btnCopy.textContent = "Copy Link"; }, 2000);
        });
      });

      actions.appendChild(btnDownload);
      actions.appendChild(btnCopy);

      card.appendChild(title);
      card.appendChild(meta);
      card.appendChild(actions);

      mediaList.appendChild(card);
    });
  }

  btnRefresh.addEventListener("click", () => {
    checkAppStatus();
    loadMedia();
  });

  checkAppStatus();
  loadMedia();
});
